package me.magnum.melonds.common

import android.app.ActivityManager
import android.content.Context
import androidx.core.content.getSystemService

object VideoRendererSupport {
    private const val Gles32Version = 0x30002

    fun supportsOpenGl(context: Context): Boolean {
        val activityManager = context.getSystemService<ActivityManager>() ?: return false
        return (activityManager.deviceConfigurationInfo?.reqGlEsVersion ?: 0) >= Gles32Version
    }
}