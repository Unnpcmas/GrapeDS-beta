#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <memory>
#include <array>
#include <string>
#include "renderer/Renderer.h"

namespace MelonDSAndroid
{

struct RenderSettings
{
};

struct SoftwareRenderSettings : public RenderSettings
{
    bool threadedRendering;
};

struct OpenGlRenderSettings : public RenderSettings
{
    bool betterPolygons;
    int scale;
};

struct ComputeRenderSettings : public RenderSettings
{
    int scale;
    bool highResCoordinates;
};

struct AudioSettings
{
    bool soundEnabled;
    int volume;
    int audioInterpolation;
    int audioBitrate;
    int audioLatency;
    int micSource;
};

struct SdCardSettings
{
    bool enabled;
    char* imagePath;
    int imageSize;
    bool readOnly;
    bool folderSync;
    char* folderPath;
};

typedef struct
{
    std::array<char16_t, 11> username;
    int language;
    int birthdayMonth;
    int birthdayDay;
    int favouriteColour;
    std::array<char16_t, 27> message;
    bool randomizeMacAddress;
    char macAddress[18];
} FirmwareConfiguration;

typedef struct
{
    bool userInternalFirmwareAndBios;
    std::string dsBios7Path;
    std::string dsBios9Path;
    std::string dsFirmwarePath;
    std::string dsiBios7Path;
    std::string dsiBios9Path;
    std::string dsiFirmwarePath;
    std::string dsiNandPath;
    std::string internalFilesDir;
    float fastForwardSpeedMultiplier;
    int presentationFps;
    bool showBootScreen;
    bool useJit;
    int consoleType;
    AudioSettings audioSettings;
    int rewindEnabled;
    int rewindCaptureSpacingSeconds;
    int rewindLengthSeconds;
    FirmwareConfiguration firmwareConfiguration;
    std::unique_ptr<RenderSettings> renderSettings;
    SdCardSettings dsiSdCardSettings;
    SdCardSettings dldiSdCardSettings;
    Renderer renderer;
} EmulatorConfiguration;

}

#endif
