#include <jni.h>
#include <algorithm>
#include <array>
#include <cstring>
#include <string>
#include "MelonDSAndroidConfiguration.h"
#include "FixedUtf16.h"
#include "renderer/Renderer.h"

namespace
{

class ScopedUtfChars
{
public:
    ScopedUtfChars(JNIEnv* env, jstring value) : env(env), value(value),
        chars(value != nullptr && !env->ExceptionCheck()
            ? env->GetStringUTFChars(value, nullptr)
            : nullptr)
    {
    }

    ~ScopedUtfChars()
    {
        if (chars != nullptr)
            env->ReleaseStringUTFChars(value, chars);
    }

    const char* get() const { return chars; }

private:
    JNIEnv* env;
    jstring value;
    const char* chars;
};

std::string CopyJavaUtf8(JNIEnv* env, jstring value)
{
    ScopedUtfChars chars(env, value);
    return chars.get() != nullptr ? std::string(chars.get()) : std::string();
}

template <std::size_t Capacity>
void CopyJavaUtf16(JNIEnv* env, jstring value, std::array<char16_t, Capacity>& destination)
{
    destination.fill(u'\0');
    if (value == nullptr || env->ExceptionCheck())
        return;

    const jsize javaLength = env->GetStringLength(value);
    if (env->ExceptionCheck())
        return;

    std::array<jchar, Capacity> input {};
    const jsize copiedLength = std::min<jsize>(javaLength, static_cast<jsize>(Capacity));
    if (copiedLength != 0)
    {
        env->GetStringRegion(value, 0, copiedLength, input.data());
        if (env->ExceptionCheck())
            return;
    }
    MelonDSAndroid::CopyFixedUtf16(destination, input.data(),
                                  static_cast<std::size_t>(copiedLength));
}

}

MelonDSAndroid::EmulatorConfiguration MelonDSAndroidConfiguration::buildEmulatorConfiguration(JNIEnv* env, jobject emulatorConfiguration) {
    if (emulatorConfiguration == nullptr || env->ExceptionCheck())
    {
        MelonDSAndroid::EmulatorConfiguration emptyConfiguration {};
        if (emulatorConfiguration == nullptr && !env->ExceptionCheck())
        {
            jclass exceptionClass = env->FindClass("java/lang/NullPointerException");
            if (exceptionClass != nullptr)
                env->ThrowNew(exceptionClass, "Emulator configuration must not be null");
        }
        return emptyConfiguration;
    }

    jclass emulatorConfigurationClass = env->GetObjectClass(emulatorConfiguration);
    jclass uriClass = env->FindClass("android/net/Uri");
    jclass consoleTypeEnumClass = env->FindClass("me/magnum/melonds/domain/model/ConsoleType");
    jclass audioBitrateEnumClass = env->FindClass("me/magnum/melonds/domain/model/AudioBitrate");
    jclass audioInterpolationEnumClass = env->FindClass("me/magnum/melonds/domain/model/AudioInterpolation");
    jclass audioLatencyEnumClass = env->FindClass("me/magnum/melonds/domain/model/AudioLatency");
    jclass micSourceEnumClass = env->FindClass("me/magnum/melonds/domain/model/MicSource");
    jclass videoRendererEnumClass = env->FindClass("me/magnum/melonds/domain/model/VideoRenderer");
    jclass renderConfigurationClass = env->FindClass("me/magnum/melonds/domain/model/RendererConfiguration");

    jmethodID uriToStringMethod = env->GetMethodID(uriClass, "toString", "()Ljava/lang/String;");

    jobject firmwareConfigurationObject = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "firmwareConfiguration", "Lme/magnum/melonds/domain/model/FirmwareConfiguration;"));
    jobject rendererConfigurationObject = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "rendererConfiguration", "Lme/magnum/melonds/domain/model/RendererConfiguration;"));
    jboolean useCustomBios = env->GetBooleanField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "useCustomBios", "Z"));
    jboolean showBootScreen = env->GetBooleanField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "showBootScreen", "Z"));
    jobject dsBios7Uri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsBios7Uri", "Landroid/net/Uri;"));
    jobject dsBios9Uri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsBios9Uri", "Landroid/net/Uri;"));
    jobject dsFirmwareUri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsFirmwareUri", "Landroid/net/Uri;"));
    jobject dsiBios7Uri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsiBios7Uri", "Landroid/net/Uri;"));
    jobject dsiBios9Uri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsiBios9Uri", "Landroid/net/Uri;"));
    jobject dsiFirmwareUri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsiFirmwareUri", "Landroid/net/Uri;"));
    jobject dsiNandUri = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "dsiNandUri", "Landroid/net/Uri;"));
    jstring internalFilesDir = (jstring) env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "internalDirectory", "Ljava/lang/String;"));
    jfloat fastForwardMaxSpeed = env->GetFloatField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "fastForwardSpeedMultiplier", "F"));
    jint presentationFps = env->GetIntField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "presentationFps", "I"));
    jboolean enableRewind = env->GetBooleanField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "rewindEnabled", "Z"));
    jint rewindPeriodSeconds = env->GetIntField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "rewindPeriodSeconds", "I"));
    jint rewindWindowSeconds = env->GetIntField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "rewindWindowSeconds", "I"));
    jboolean useJit = env->GetBooleanField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "useJit", "Z"));
    jobject consoleTypeEnum = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "consoleType", "Lme/magnum/melonds/domain/model/ConsoleType;"));
    jint consoleType = env->GetIntField(consoleTypeEnum, env->GetFieldID(consoleTypeEnumClass, "consoleType", "I"));
    jboolean soundEnabled = env->GetBooleanField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "soundEnabled", "Z"));
    jint volume = env->GetIntField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "volume", "I"));
    jobject audioInterpolationEnum = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "audioInterpolation", "Lme/magnum/melonds/domain/model/AudioInterpolation;"));
    jint audioInterpolation = env->GetIntField(audioInterpolationEnum, env->GetFieldID(audioInterpolationEnumClass, "interpolationValue", "I"));
    jobject audioBitrateEnum = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "audioBitrate", "Lme/magnum/melonds/domain/model/AudioBitrate;"));
    jint audioBitrate = env->GetIntField(audioBitrateEnum, env->GetFieldID(audioBitrateEnumClass, "bitrateValue", "I"));
    jobject audioLatencyEnum = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "audioLatency", "Lme/magnum/melonds/domain/model/AudioLatency;"));
    jint audioLatency = env->GetIntField(audioLatencyEnum, env->GetFieldID(audioLatencyEnumClass, "latencyValue", "I"));
    jobject micSourceEnum = env->GetObjectField(emulatorConfiguration, env->GetFieldID(emulatorConfigurationClass, "micSource", "Lme/magnum/melonds/domain/model/MicSource;"));
    jint micSource = env->GetIntField(micSourceEnum, env->GetFieldID(micSourceEnumClass, "sourceValue", "I"));
    jobject videoRendererEnum = env->GetObjectField(rendererConfigurationObject, env->GetFieldID(renderConfigurationClass, "renderer", "Lme/magnum/melonds/domain/model/VideoRenderer;"));
    MelonDSAndroid::Renderer videoRenderer = static_cast<MelonDSAndroid::Renderer>(env->GetIntField(videoRendererEnum, env->GetFieldID(videoRendererEnumClass, "renderer", "I")));
    const auto uriToString = [env, uriToStringMethod](jobject uri) -> jstring {
        if (uri == nullptr || uriToStringMethod == nullptr || env->ExceptionCheck())
            return nullptr;
        return static_cast<jstring>(env->CallObjectMethod(uri, uriToStringMethod));
    };
    jstring dsBios7String = uriToString(dsBios7Uri);
    jstring dsBios9String = uriToString(dsBios9Uri);
    jstring dsFirmwareString = uriToString(dsFirmwareUri);
    jstring dsiBios7String = uriToString(dsiBios7Uri);
    jstring dsiBios9String = uriToString(dsiBios9Uri);
    jstring dsiFirmwareString = uriToString(dsiFirmwareUri);
    jstring dsiNandString = uriToString(dsiNandUri);
    const std::string dsBios7Path = CopyJavaUtf8(env, dsBios7String);
    const std::string dsBios9Path = CopyJavaUtf8(env, dsBios9String);
    const std::string dsFirmwarePath = CopyJavaUtf8(env, dsFirmwareString);
    const std::string dsiBios7Path = CopyJavaUtf8(env, dsiBios7String);
    const std::string dsiBios9Path = CopyJavaUtf8(env, dsiBios9String);
    const std::string dsiFirmwarePath = CopyJavaUtf8(env, dsiFirmwareString);
    const std::string dsiNandPath = CopyJavaUtf8(env, dsiNandString);
    const std::string internalDir = CopyJavaUtf8(env, internalFilesDir);

    MelonDSAndroid::EmulatorConfiguration finalEmulatorConfiguration {};
    if (env->ExceptionCheck())
        return finalEmulatorConfiguration;
    finalEmulatorConfiguration.userInternalFirmwareAndBios = !useCustomBios;
    finalEmulatorConfiguration.dsBios7Path = dsBios7Path;
    finalEmulatorConfiguration.dsBios9Path = dsBios9Path;
    finalEmulatorConfiguration.dsFirmwarePath = dsFirmwarePath;
    finalEmulatorConfiguration.dsiBios7Path = dsiBios7Path;
    finalEmulatorConfiguration.dsiBios9Path = dsiBios9Path;
    finalEmulatorConfiguration.dsiFirmwarePath = dsiFirmwarePath;
    finalEmulatorConfiguration.dsiNandPath = dsiNandPath;
    finalEmulatorConfiguration.internalFilesDir = internalDir;
    finalEmulatorConfiguration.fastForwardSpeedMultiplier = fastForwardMaxSpeed;
    finalEmulatorConfiguration.presentationFps = presentationFps;
    finalEmulatorConfiguration.showBootScreen = showBootScreen;
    finalEmulatorConfiguration.useJit = useJit;
    finalEmulatorConfiguration.consoleType = consoleType;
    finalEmulatorConfiguration.audioSettings = MelonDSAndroid::AudioSettings {
        .soundEnabled = (bool) soundEnabled,
        .volume = volume,
        .audioInterpolation = audioInterpolation,
        .audioBitrate = audioBitrate,
        .audioLatency = audioLatency,
        .micSource = micSource
    };
    finalEmulatorConfiguration.firmwareConfiguration = buildFirmwareConfiguration(env, firmwareConfigurationObject);
    if (env->ExceptionCheck())
        return finalEmulatorConfiguration;
    finalEmulatorConfiguration.rewindEnabled = enableRewind ? 1 : 0;
    finalEmulatorConfiguration.rewindCaptureSpacingSeconds = rewindPeriodSeconds;
    finalEmulatorConfiguration.rewindLengthSeconds = rewindWindowSeconds;
    finalEmulatorConfiguration.renderSettings = std::move(buildRenderSettings(env, videoRenderer, rendererConfigurationObject));
    finalEmulatorConfiguration.dsiSdCardSettings = MelonDSAndroid::SdCardSettings { .enabled = false };
    finalEmulatorConfiguration.dldiSdCardSettings = MelonDSAndroid::SdCardSettings { .enabled = false };
    finalEmulatorConfiguration.renderer = videoRenderer;
    return finalEmulatorConfiguration;
}

MelonDSAndroid::FirmwareConfiguration MelonDSAndroidConfiguration::buildFirmwareConfiguration(JNIEnv* env, jobject firmwareConfiguration) {
    MelonDSAndroid::FirmwareConfiguration finalFirmwareConfiguration {};
    if (firmwareConfiguration == nullptr || env->ExceptionCheck())
        return finalFirmwareConfiguration;

    jclass firmwareConfigurationClass = env->GetObjectClass(firmwareConfiguration);
    jstring nicknameString = (jstring) env->GetObjectField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "nickname", "Ljava/lang/String;"));
    jstring messageString = (jstring) env->GetObjectField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "message", "Ljava/lang/String;"));
    int language = env->GetIntField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "language", "I"));
    int colour = env->GetIntField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "favouriteColour", "I"));
    int birthdayDay = env->GetIntField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "birthdayDay", "I"));
    int birthdayMonth = env->GetIntField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "birthdayMonth", "I"));
    bool randomizeMacAddress = env->GetBooleanField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "randomizeMacAddress", "Z"));
    jstring macAddressString = (jstring) env->GetObjectField(firmwareConfiguration, env->GetFieldID(firmwareConfigurationClass, "internalMacAddress", "Ljava/lang/String;"));

    CopyJavaUtf16(env, nicknameString, finalFirmwareConfiguration.username);
    CopyJavaUtf16(env, messageString, finalFirmwareConfiguration.message);
    const std::string macAddress = CopyJavaUtf8(env, macAddressString);
    if (env->ExceptionCheck())
        return finalFirmwareConfiguration;
    finalFirmwareConfiguration.language = language;
    finalFirmwareConfiguration.favouriteColour = colour;
    finalFirmwareConfiguration.birthdayDay = birthdayDay;
    finalFirmwareConfiguration.birthdayMonth = birthdayMonth;
    finalFirmwareConfiguration.randomizeMacAddress = randomizeMacAddress;
    if (!macAddress.empty())
    {
        strncpy(finalFirmwareConfiguration.macAddress, macAddress.c_str(), sizeof(finalFirmwareConfiguration.macAddress) - 1);
        finalFirmwareConfiguration.macAddress[sizeof(finalFirmwareConfiguration.macAddress) - 1] = '\0';
    }
    else
    {
        finalFirmwareConfiguration.macAddress[0] = '\0';
    }

    return finalFirmwareConfiguration;
}

std::unique_ptr<MelonDSAndroid::RenderSettings> MelonDSAndroidConfiguration::buildRenderSettings(JNIEnv* env, MelonDSAndroid::Renderer renderer, jobject renderSettings) {
    jclass renderSettingsClass = env->GetObjectClass(renderSettings);
    jmethodID getResolutionScalingMethod = env->GetMethodID(renderSettingsClass, "getResolutionScaling", "()I");
    jboolean threadedRendering = env->GetBooleanField(renderSettings, env->GetFieldID(renderSettingsClass, "threadedRendering", "Z"));
    jint internalResolutionScaling = env->CallIntMethod(renderSettings, getResolutionScalingMethod);

    std::unique_ptr<MelonDSAndroid::RenderSettings> settings;
    if (renderer == MelonDSAndroid::Renderer::OpenGl)
    {
        settings = std::make_unique<MelonDSAndroid::OpenGlRenderSettings>(
            MelonDSAndroid::OpenGlRenderSettings {
                .betterPolygons = false,
                .scale = internalResolutionScaling,
            }
        );
    }
    else if (renderer == MelonDSAndroid::Renderer::Compute)
    {
        settings = std::make_unique<MelonDSAndroid::ComputeRenderSettings>(
            MelonDSAndroid::ComputeRenderSettings {
                .scale = internalResolutionScaling,
                .highResCoordinates = true,
            }
        );
    }
    else
    {
        settings = std::make_unique<MelonDSAndroid::SoftwareRenderSettings>(
            MelonDSAndroid::SoftwareRenderSettings {
                .threadedRendering = (bool) threadedRendering
            }
        );
    }

    return settings;
}