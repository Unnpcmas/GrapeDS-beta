#ifndef FIXEDUTF16_H
#define FIXEDUTF16_H

#include <algorithm>
#include <array>
#include <cstddef>

namespace MelonDSAndroid
{

template <std::size_t Capacity, typename Char>
std::size_t CopyFixedUtf16(std::array<char16_t, Capacity>& destination,
                           const Char* source, std::size_t sourceLength) noexcept
{
    static_assert(Capacity > 0, "A fixed UTF-16 string needs room for a terminator");
    destination.fill(u'\0');
    if (source == nullptr)
        return 0;

    constexpr char16_t ReplacementCharacter = u'\uFFFD';
    const std::size_t maxLength = Capacity - 1;
    std::size_t input = 0;
    std::size_t output = 0;
    while (input < sourceLength && source[input] != 0 && output < maxLength)
    {
        const char16_t current = static_cast<char16_t>(source[input++]);
        if (current >= 0xD800 && current <= 0xDBFF)
        {
            if (input < sourceLength)
            {
                const char16_t next = static_cast<char16_t>(source[input]);
                if (next >= 0xDC00 && next <= 0xDFFF)
                {
                    if (output + 2 > maxLength)
                        break;
                    destination[output++] = current;
                    destination[output++] = next;
                    ++input;
                    continue;
                }
            }
            destination[output++] = ReplacementCharacter;
        }
        else if (current >= 0xDC00 && current <= 0xDFFF)
        {
            destination[output++] = ReplacementCharacter;
        }
        else
        {
            destination[output++] = current;
        }
    }
    return output;
}

}

#endif