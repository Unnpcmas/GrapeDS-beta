#include "UriFileHandler.h"
#include "Platform.h"
#include <unistd.h>

using namespace melonDS::Platform;

UriFileHandler::UriFileHandler(JniEnvHandler* jniEnvHandler, jobject uriFileHandler)
{
    this->jniEnvHandler = jniEnvHandler;
    this->uriFileHandler = uriFileHandler;
}

FILE* UriFileHandler::open(const char* path, FileMode mode)
{
    if (this->jniEnvHandler == nullptr || this->uriFileHandler == nullptr || path == nullptr)
    {
        melonDS::Platform::Log(melonDS::Platform::LogLevel::Error, "Cannot open URI file with an invalid JNI handler or path");
        return nullptr;
    }

    JNIEnv* env = this->jniEnvHandler->getCurrentThreadEnv();
    if (env == nullptr)
        return nullptr;

    jstring pathString = env->NewStringUTF(path);
    jstring modeString = env->NewStringUTF(getAccessMode(mode, false).c_str());
    if (pathString == nullptr || modeString == nullptr || env->ExceptionCheck())
    {
        env->ExceptionClear();
        if (pathString != nullptr) env->DeleteLocalRef(pathString);
        if (modeString != nullptr) env->DeleteLocalRef(modeString);
        melonDS::Platform::Log(melonDS::Platform::LogLevel::Error, "Could not create JNI strings for URI file open");
        return nullptr;
    }

    jclass handlerClass = env->GetObjectClass(this->uriFileHandler);
    if (handlerClass == nullptr || env->ExceptionCheck())
    {
        env->ExceptionClear();
        env->DeleteLocalRef(pathString);
        env->DeleteLocalRef(modeString);
        return nullptr;
    }

    jmethodID openMethod = env->GetMethodID(handlerClass, "open", "(Ljava/lang/String;Ljava/lang/String;)I");
    if (openMethod == nullptr || env->ExceptionCheck())
    {
        env->ExceptionClear();
        env->DeleteLocalRef(handlerClass);
        env->DeleteLocalRef(pathString);
        env->DeleteLocalRef(modeString);
        return nullptr;
    }

    jint fileDescriptor = env->CallIntMethod(this->uriFileHandler, openMethod, pathString, modeString);
    const bool callFailed = env->ExceptionCheck();
    if (callFailed)
        env->ExceptionClear();
    env->DeleteLocalRef(handlerClass);
    env->DeleteLocalRef(pathString);
    env->DeleteLocalRef(modeString);

    if (callFailed || fileDescriptor == -1) {
        return nullptr;
    } else {
        std::string nativeMode = getNativeAccessMode(mode, false);
        FILE* file = fdopen(fileDescriptor, nativeMode.c_str());
        if (file == nullptr)
            close(fileDescriptor);
        return file;
    }
}

std::string UriFileHandler::getNativeAccessMode(FileMode mode, bool fileExists)
{
    std::string modeString;

    if (mode & FileMode::Append)
        modeString += 'a';
    else if (!(mode & FileMode::Write))
        // If we're only opening the file for reading...
        modeString += 'r';
    else if (mode & (FileMode::NoCreate))
        // If we're not allowed to create a new file...
        modeString += 'r'; // Open in "r+" mode (IsExtended will add the "+")
    else if ((mode & FileMode::Preserve) && fileExists)
        // If we're not allowed to overwrite a file that already exists...
        modeString += 'r'; // Open in "r+" mode (IsExtended will add the "+")
    else
        modeString += 'w';

    if ((mode & FileMode::ReadWrite) == FileMode::ReadWrite)
        modeString += '+';

    if (!(mode & FileMode::Text))
        modeString += 'b';

    return modeString;
}

std::string UriFileHandler::getAccessMode(FileMode mode, bool fileExists)
{
    std::string modeString;

    if (mode & FileMode::Read)
        modeString += 'r';

    if (mode & FileMode::Write)
    {
        modeString += 'w';

        if (mode & FileMode::Append)
            modeString += 'a';
        else if (!(mode & FileMode::Preserve))
            modeString += 't';
    }
    else if (mode & FileMode::Append)
        modeString += "wa";

    return modeString;
}

UriFileHandler::~UriFileHandler()
{
}