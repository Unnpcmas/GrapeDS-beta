# Building and using Grape DS

## Compact arm64 beta

Use Java 21 and the Android SDK, NDK, and CMake versions declared in the Gradle configuration.

```sh
sh ./gradlew :app:assembleGitHubProdDebug \
  -PgrapeDsAbis=arm64-v8a -PgrapeDsCompact=true \
  --no-daemon --max-workers=1
```

The APK is generated under `app/build/outputs/apk/gitHubProd/debug/`.
The compact option enables code/resource shrinking, not removal of emulator features.
It retains the normal debug signing configuration and `com.grapeds.android` package.
Updates require the same signing certificate as the installed APK.
Keep R8 mapping files from `app/build/outputs/mapping/` with each distributed build for diagnosing obfuscated traces.

Omit `-PgrapeDsCompact=true` to build an unminified diagnostic APK.

## Verification

```sh
sh ./gradlew :app:testGitHubProdDebugUnitTest --no-daemon --max-workers=1
bash tests/emulator_args_loader_safety_test.sh
```

Host/JVM tests do not replace testing actual game startup on an Android device.

## DS games without external firmware

Select **Nintendo DS (built-in BIOS)** in a game's system settings.
The ordinary DS misconfiguration dialog also offers **Use built-in BIOS**.
This changes only that game's configuration; existing custom folders and global settings remain available.
DSi/DSiWare and booting external firmware still require their own valid files.

File indicators distinguish missing, unreadable, and wrong-sized files.
A readable file with an accepted size is not proof that its contents are a genuine BIOS dump.
NAND validation checks accessibility only; the native loader performs the actual image/mount checks.

ROM cache cleanup does not reduce APK size. It removes disposable extraction data,
not saved games; cache entries may need to be extracted again on a later launch.