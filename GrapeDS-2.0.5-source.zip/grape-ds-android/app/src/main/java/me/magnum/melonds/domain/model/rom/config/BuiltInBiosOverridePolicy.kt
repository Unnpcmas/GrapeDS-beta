package me.magnum.melonds.domain.model.rom.config

import me.magnum.melonds.domain.model.ConsoleType

object BuiltInBiosOverridePolicy {
    fun canUseBuiltInBiosForRom(
        globalConsoleType: ConsoleType,
        globalUseCustomBios: Boolean,
        runtimeConsoleType: RuntimeConsoleType,
        isDsiWareTitle: Boolean,
    ): Boolean {
        val configuration = RomEmulatorConfigurationResolver.resolve(
            globalConsoleType = globalConsoleType,
            globalUseCustomBios = globalUseCustomBios,
            runtimeConsoleType = runtimeConsoleType,
            isDsiWareTitle = isDsiWareTitle,
        )
        return canUseBuiltInBios(
            isFirmwareLaunch = false,
            isDsiWareTitle = isDsiWareTitle,
            effectiveConsoleType = configuration.consoleType,
        )
    }

    fun canUseBuiltInBios(
        isFirmwareLaunch: Boolean,
        isDsiWareTitle: Boolean,
        effectiveConsoleType: ConsoleType,
    ): Boolean {
        return !isFirmwareLaunch &&
            !isDsiWareTitle &&
            effectiveConsoleType == ConsoleType.DS
    }
}