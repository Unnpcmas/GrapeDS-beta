package me.magnum.melonds.domain.model.rom.config

import me.magnum.melonds.domain.model.ConsoleType

data class ResolvedRomEmulatorConfiguration(
    val consoleType: ConsoleType,
    val useCustomBios: Boolean,
)

object RomEmulatorConfigurationResolver {
    fun resolve(
        globalConsoleType: ConsoleType,
        globalUseCustomBios: Boolean,
        runtimeConsoleType: RuntimeConsoleType,
        isDsiWareTitle: Boolean,
    ): ResolvedRomEmulatorConfiguration {
        if (isDsiWareTitle && runtimeConsoleType == RuntimeConsoleType.DS_INTERNAL) {
            return ResolvedRomEmulatorConfiguration(
                consoleType = ConsoleType.DSi,
                useCustomBios = true,
            )
        }

        val consoleType = runtimeConsoleType.targetConsoleType ?: globalConsoleType
        val useCustomBios = when (runtimeConsoleType) {
            RuntimeConsoleType.DS_INTERNAL -> false
            RuntimeConsoleType.DEFAULT -> globalUseCustomBios || consoleType == ConsoleType.DSi
            RuntimeConsoleType.DS,
            RuntimeConsoleType.DSi -> true
        }
        return ResolvedRomEmulatorConfiguration(
            consoleType = consoleType,
            useCustomBios = useCustomBios,
        )
    }
}