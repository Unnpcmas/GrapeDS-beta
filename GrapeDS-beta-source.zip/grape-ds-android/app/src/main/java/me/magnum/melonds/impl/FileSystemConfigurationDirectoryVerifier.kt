package me.magnum.melonds.impl

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import me.magnum.melonds.domain.model.ConfigurationDirResult
import me.magnum.melonds.domain.model.ConsoleType
import me.magnum.melonds.domain.repositories.SettingsRepository
import me.magnum.melonds.domain.services.ConfigurationDirectoryVerifier
import java.io.IOException
import java.io.InputStream

private const val BOUNDED_READ_BUFFER_SIZE = 8192

/**
 * Counts at most [limit] bytes without allocating storage proportional to the file.
 *
 * A result equal to [limit] means that the stream contains at least that many bytes.
 * IO failures are deliberately propagated so callers cannot mistake an unreadable file
 * for a valid one.
 */
internal fun readLengthBounded(input: InputStream, limit: Long): Long {
    require(limit > 0)

    val buffer = ByteArray(minOf(BOUNDED_READ_BUFFER_SIZE.toLong(), limit).toInt())
    var total = 0L
    while (total < limit) {
        val requested = minOf(buffer.size.toLong(), limit - total).toInt()
        val count = input.read(buffer, 0, requested)
        if (count < 0) break
        if (count == 0) {
            if (input.read() < 0) break
            total++
        } else {
            total += count
        }
    }
    return total
}

class FileSystemConfigurationDirectoryVerifier(private val context: Context, settingsRepository: SettingsRepository) : ConfigurationDirectoryVerifier(settingsRepository) {
    override fun checkDsConfigurationDirectory(directory: Uri?): ConfigurationDirResult {
        return checkConfigurationDirectory(ConsoleType.DS, directory)
    }

    override fun checkDsiConfigurationDirectory(directory: Uri?): ConfigurationDirResult {
        return checkConfigurationDirectory(ConsoleType.DSi, directory)
    }

    private fun checkConfigurationDirectory(consoleType: ConsoleType, directory: Uri?): ConfigurationDirResult {
        val requiredFiles = getRequiredFilesVerifiers(consoleType)
        if (directory == null) {
            val fileResults = requiredFiles.map { it.key to ConfigurationDirResult.FileStatus.MISSING }
            return ConfigurationDirResult(consoleType, ConfigurationDirResult.Status.UNSET, requiredFiles.keys.toTypedArray(), fileResults.toTypedArray())
        }

        val dirDocument = try {
            DocumentFile.fromTreeUri(context, directory)
        } catch (e: SecurityException) {
            return unavailableDirectoryResult(consoleType, requiredFiles)
        } catch (e: IllegalArgumentException) {
            return unavailableDirectoryResult(consoleType, requiredFiles)
        }
        val isDirectory = try {
            dirDocument?.isDirectory == true
        } catch (e: SecurityException) {
            return unavailableDirectoryResult(consoleType, requiredFiles)
        } catch (e: IllegalArgumentException) {
            return unavailableDirectoryResult(consoleType, requiredFiles)
        }
        if (dirDocument == null || !isDirectory) {
            val fileResults = requiredFiles.map { it.key to ConfigurationDirResult.FileStatus.MISSING }
            return ConfigurationDirResult(consoleType, ConfigurationDirResult.Status.INVALID, requiredFiles.keys.toTypedArray(), fileResults.toTypedArray())
        }

        val fileResults = requiredFiles.map {
            it.key to it.value.invoke(dirDocument)
        }

        val result = if (fileResults.any { it.second != ConfigurationDirResult.FileStatus.PRESENT }) {
            ConfigurationDirResult.Status.INVALID
        } else {
            ConfigurationDirResult.Status.VALID
        }
        return ConfigurationDirResult(consoleType, result, requiredFiles.keys.toTypedArray(), fileResults.toTypedArray())
    }

    private fun unavailableDirectoryResult(
        consoleType: ConsoleType,
        requiredFiles: Map<String, (DocumentFile) -> ConfigurationDirResult.FileStatus>
    ): ConfigurationDirResult {
        val fileResults = requiredFiles.map { it.key to ConfigurationDirResult.FileStatus.UNREADABLE }
        return ConfigurationDirResult(
            consoleType,
            ConfigurationDirResult.Status.INVALID,
            requiredFiles.keys.toTypedArray(),
            fileResults.toTypedArray()
        )
    }

    private fun getDSBios7Status(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getBiosFileStatus(configurationDir, "bios7.bin", 0x4000.toLong())
    }

    private fun getDSBios9Status(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getBiosFileStatus(configurationDir, "bios9.bin", 0x1000.toLong())
    }

    private fun getDSFirmwareStatus(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getSizedFileStatus(
            configurationDir,
            "firmware.bin",
            longArrayOf(0x20000L, 0x40000L, 0x80000L)
        )
    }

    private fun getDSiBios7Status(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getBiosFileStatus(configurationDir, "bios7.bin", 0x10000.toLong())
    }

    private fun getDSiBios9Status(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getBiosFileStatus(configurationDir, "bios9.bin", 0x10000.toLong())
    }

    private fun getDSiFirmwareStatus(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return getSizedFileStatus(configurationDir, "firmware.bin", longArrayOf(0x20000L))
    }

    private fun getDSiNandStatus(configurationDir: DocumentFile): ConfigurationDirResult.FileStatus {
        return try {
            val nandDocument = configurationDir.findFile("nand.bin")
                ?: return ConfigurationDirResult.FileStatus.MISSING
            if (!nandDocument.isFile) return ConfigurationDirResult.FileStatus.INVALID

            val byteCount = context.contentResolver.openInputStream(nandDocument.uri)?.use {
                readLengthBounded(it, 1L)
            } ?: return ConfigurationDirResult.FileStatus.UNREADABLE
            if (byteCount > 0L) ConfigurationDirResult.FileStatus.PRESENT else ConfigurationDirResult.FileStatus.INVALID
        } catch (e: SecurityException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        } catch (e: IllegalArgumentException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        } catch (e: IOException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        }
    }

    private fun getBiosFileStatus(configurationDir: DocumentFile, fileName: String, requiredSize: Long): ConfigurationDirResult.FileStatus {
        return getSizedFileStatus(configurationDir, fileName, longArrayOf(requiredSize))
    }

    private fun getSizedFileStatus(
        configurationDir: DocumentFile,
        fileName: String,
        acceptedSizes: LongArray
    ): ConfigurationDirResult.FileStatus {
        return try {
            val document = configurationDir.findFile(fileName)
                ?: return ConfigurationDirResult.FileStatus.MISSING
            if (!document.isFile) return ConfigurationDirResult.FileStatus.INVALID

            val measuredSize = context.contentResolver.openInputStream(document.uri)?.use {
                readLengthBounded(it, acceptedSizes.maxOrNull()!! + 1L)
            } ?: return ConfigurationDirResult.FileStatus.UNREADABLE
            if (measuredSize in acceptedSizes) {
                ConfigurationDirResult.FileStatus.PRESENT
            } else {
                ConfigurationDirResult.FileStatus.INVALID
            }
        } catch (e: SecurityException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        } catch (e: IllegalArgumentException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        } catch (e: IOException) {
            ConfigurationDirResult.FileStatus.UNREADABLE
        }
    }

    private fun getRequiredFilesVerifiers(consoleType: ConsoleType): Map<String, (DocumentFile) -> ConfigurationDirResult.FileStatus> {
        return when(consoleType) {
            ConsoleType.DS -> mapOf(
                    "bios7.bin" to this::getDSBios7Status,
                    "bios9.bin" to this::getDSBios9Status,
                    "firmware.bin" to this::getDSFirmwareStatus
            )
            ConsoleType.DSi -> mapOf(
                    "bios7.bin" to this::getDSiBios7Status,
                    "bios9.bin" to this::getDSiBios9Status,
                    "firmware.bin" to this::getDSiFirmwareStatus,
                    "nand.bin" to this::getDSiNandStatus
            )
        }
    }
}