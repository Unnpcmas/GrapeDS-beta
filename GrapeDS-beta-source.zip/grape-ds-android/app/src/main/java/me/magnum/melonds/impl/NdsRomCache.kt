package me.magnum.melonds.impl

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.receiveAsFlow
import me.magnum.melonds.domain.model.rom.Rom
import me.magnum.melonds.domain.model.SizeUnit
import me.magnum.melonds.domain.repositories.SettingsRepository
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class NdsRomCache(private val context: Context, private val settingsRepository: SettingsRepository) {
    companion object {
        private const val ROMS_CACHE_DIR = "extracted_roms_v2"
        private const val LEGACY_ROMS_CACHE_DIR = "extracted_roms"
        private const val TEMP_FILE_PREFIX = ".tmp-"
        private const val BACKUP_FILE_PREFIX = ".backup-"
    }

    private class CouldNotCreateRomCacheDirectoryException : Exception("Failed to create ROM cache directory")

    private val cacheModifiedSubject = Channel<Unit>(Channel.CONFLATED)
    private val cacheLock = Any()

    init {
        // Older Grape DS builds used a shared "temp" file and could leave a
        // partial ROM behind. Never feed those files back into the emulator.
        context.externalCacheDir?.let { File(it, LEGACY_ROMS_CACHE_DIR).deleteRecursively() }
    }

    fun getCacheSizeFlow(): Flow<SizeUnit> {
        return cacheModifiedSubject.receiveAsFlow()
            .onStart { emit(Unit) }
            .map { calculateCacheSize() }
    }

    fun clearCache(): Boolean {
        val externalCacheDir = context.externalCacheDir ?: return false
        val result = synchronized(cacheLock) {
            val currentCacheDeleted = File(externalCacheDir, ROMS_CACHE_DIR).let {
                !it.exists() || it.deleteRecursively()
            }
            val legacyCacheDeleted = File(externalCacheDir, LEGACY_ROMS_CACHE_DIR).let {
                !it.exists() || it.deleteRecursively()
            }
            currentCacheDeleted && legacyCacheDeleted
        }
        cacheModifiedSubject.trySend(Unit)

        return result
    }

    fun getCachedRomFile(rom: Rom, forUse: Boolean = false): Uri? {
        val romHash = rom.uri.hashCode().toString()
        val romCacheDir = context.externalCacheDir?.let { File(it, ROMS_CACHE_DIR) }
        if (romCacheDir == null || !romCacheDir.isDirectory) {
            return null
        }

        val romFile = File(romCacheDir, romHash)
        return if (romFile.isFile) {
            if (forUse) {
                romFile.setLastModified(Date().time)
            }

            DocumentFile.fromFile(romFile).uri
        } else {
            null
        }
    }

    /**
     * Caches the file of the provided ROM. The caller is responsible for copying the contents of the file into the [FileOutputStream] provided by the [romExtractor].
     *
     * @param rom The ROM whose file will be cached
     * @param romExtractor The handler that caller should use to provided the contents of the ROM's file. The callback should return true if the operation was successful
     * or false if a problem occurred or the operation was interrupted. If false is returned, the cached file is deleted
     */
    fun cacheRom(rom: Rom, romExtractor: RomExtractor) {
        synchronized(cacheLock) {
            val romCacheDir = context.externalCacheDir?.let { File(it, ROMS_CACHE_DIR) }
            if (romCacheDir == null || !(romCacheDir.isDirectory || romCacheDir.mkdirs())) {
                throw CouldNotCreateRomCacheDirectoryException()
            }

            val romHash = rom.uri.hashCode().toString()
            val cachedFile = File(romCacheDir, romHash)
            val tempCachedFile = File.createTempFile("$TEMP_FILE_PREFIX$romHash-", ".rom", romCacheDir)
            var backupFile: File? = null

            try {
                val romFileSize = romExtractor.getExtractedRomFileSize()
                freeCacheSpaceIfRequired(romFileSize, cachedFile)

                val success = tempCachedFile.outputStream().use {
                    romExtractor.saveRomFile(it)
                }
                if (!success) {
                    tempCachedFile.delete()
                    return@synchronized
                }
                if (!tempCachedFile.isFile) {
                    throw IOException("ROM extraction did not produce a complete cache file")
                }

                if (cachedFile.exists()) {
                    backupFile = File(romCacheDir, "$BACKUP_FILE_PREFIX$romHash-${UUID.randomUUID()}")
                    if (!cachedFile.renameTo(backupFile)) {
                        throw IOException("Could not preserve the existing cached ROM")
                    }
                }

                if (!tempCachedFile.renameTo(cachedFile)) {
                    backupFile?.renameTo(cachedFile)
                    throw IOException("Could not commit the extracted ROM to cache")
                }

                backupFile?.delete()
                cacheModifiedSubject.trySend(Unit)
            } catch (e: Exception) {
                tempCachedFile.delete()
                backupFile?.let {
                    if (!cachedFile.exists()) {
                        it.renameTo(cachedFile)
                    } else {
                        it.delete()
                    }
                }
                throw e
            }
        }
    }

    private fun calculateCacheSize(): SizeUnit {
        val romCacheDir = context.externalCacheDir?.let { File(it, ROMS_CACHE_DIR) }
        val cacheSize = romCacheDir?.listCacheFiles()?.sumOf { file: File -> file.length() } ?: 0L
        return SizeUnit.Bytes(cacheSize)
    }

    private fun freeCacheSpaceIfRequired(requiredSize: SizeUnit, targetFile: File) {
        val currentCacheSize = calculateCacheSize()
        val maxCacheSize = settingsRepository.getRomCacheMaxSize()

        // A replacement does not add both the old and new target sizes. More
        // importantly, never evict the known-good target before its replacement
        // has been extracted and atomically committed.
        val replacedSize = if (targetFile.isFile) targetFile.length() else 0L
        val requiredCacheSize = currentCacheSize + requiredSize - SizeUnit.Bytes(replacedSize)
        if (requiredCacheSize > maxCacheSize) {
            freeCacheSpace(requiredCacheSize - maxCacheSize, targetFile)
        }
    }

    private fun freeCacheSpace(sizeToFree: SizeUnit, targetFile: File) {
        val romCacheDir = context.externalCacheDir?.let { File(it, ROMS_CACHE_DIR) }
        // Use the last modified timestamp to determine the last time the ROM was used. The timestamp must be updated whenever the ROM is requested for use
        val romFilesByCreationDate = romCacheDir?.listCacheFiles(targetFile)?.sortedBy { file: File -> file.lastModified() } ?: return
        var freedBytes = SizeUnit.Bytes(0)

        for (file in romFilesByCreationDate) {
            val fileSize = file.length()
            if (file.delete()) {
                freedBytes += fileSize
            }

            if (freedBytes >= sizeToFree) {
                break
            }
        }
    }

    private fun File.listCacheFiles(preservedFile: File? = null): List<File> {
        return selectDisposableCacheFiles(
            listFiles(),
            preservedFile,
            TEMP_FILE_PREFIX,
            BACKUP_FILE_PREFIX,
        )
    }

    interface RomExtractor {
        /**
         * Returns the uncompressed size of the ROM file to be extracted.
         */
        fun getExtractedRomFileSize(): SizeUnit

        /**
         * Requests the ROM to be extracted into the given [FileOutputStream]. This function should return true if the operation was successful or false if a problem occurred
         * or the operation was interrupted. If false is returned, the cached file is deleted.
         */
        fun saveRomFile(fileStream: FileOutputStream): Boolean
    }
}

internal fun selectDisposableCacheFiles(
    files: Array<File>?,
    preservedFile: File?,
    tempFilePrefix: String,
    backupFilePrefix: String,
): List<File> {
    return files
        ?.filter {
            it.isFile &&
                it != preservedFile &&
                !it.name.startsWith(tempFilePrefix) &&
                !it.name.startsWith(backupFilePrefix)
        }
        ?: emptyList()
}